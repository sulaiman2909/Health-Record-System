/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.model;

import java.util.Date;
import java.sql.Time;

public class Appointment {
    private String id;
    private String doctorID;
    private String patientID;
    private String date;
    private String time;
    
    public Appointment() {
        
    }

    public Appointment(String id, String doctor, String patient, String date, String time) {
        this.id = id;
        this.doctorID = doctor;
        this.patientID = patient;
        this.date = date;
        this.time = time;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDoctor() {
        return doctorID;
    }

    public void setDoctor(String doctor) {
        this.doctorID = doctor;
    }

    public String getPatient() {
        return patientID;
    }

    public void setPatient(String patient) {
        this.patientID = patient;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}
