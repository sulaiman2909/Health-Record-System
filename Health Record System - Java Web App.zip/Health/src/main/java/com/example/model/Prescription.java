/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.model;

/**
 *
 * @author Dell
 */
public class Prescription {
    private String id;
    private String doctorID;
    private String patientID;
    private String dosage;
    private String duration;
    private String instructions;

    public Prescription() {
    }

    public Prescription(String id, String doctor, String patient, String dosage, String duration, String instructions) {
        this.id = id;
        this.doctorID = doctor;
        this.patientID = patient;
        this.dosage = dosage;
        this.duration = duration;
        this.instructions = instructions;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDoctor() {
        return doctorID;
    }

    public void setDoctor(String doctor) {
        this.doctorID = doctor;
    }

    public String getPatient() {
        return patientID;
    }

    public void setPatient(String patient) {
        this.patientID = patient;
    }

    public String getDosage() {
        return dosage;
    }

    public void setDosage(String dosage) {
        this.dosage = dosage;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public String getInstructions() {
        return instructions;
    }

    public void setInstructions(String instructions) {
        this.instructions = instructions;
    }
}
