/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.model;
/**
 *
 * @author Dell
 */
public class Patient extends Person{
    private String healthStatus;

    public Patient() {
        
    }
    
    public Patient(String id, String name, String contactNum, String address, String healthStatus) {
        super(id, name, contactNum, address);
        this.healthStatus = healthStatus;
    }

    public String getHealthStatus() {
        return healthStatus;
    }

    public void setHealthStatus(String healthStatus) {
        this.healthStatus = healthStatus;
    }
}
