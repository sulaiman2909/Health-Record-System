/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.exceptions;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Dell
 */
public class IdNotFoundExceptionMapper implements ExceptionMapper<IdNotFoundException>{
    private static final Logger LOGGER = LoggerFactory.getLogger(IdNotFoundExceptionMapper.class);

    @Override
    public Response toResponse(IdNotFoundException e) {
        LOGGER.error("PatientNotFoundException caught: {}", e.getMessage(), e);

        return Response.status(Response.Status.NOT_FOUND)
                .entity(e.getMessage())
                .type(MediaType.TEXT_PLAIN)
                .build();
    }
    
    
}
