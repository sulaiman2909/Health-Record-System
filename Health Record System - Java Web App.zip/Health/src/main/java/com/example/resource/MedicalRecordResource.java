/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.resource;

/**
 *
 * @author Dell
 */
import com.example.dao.MedicalRecordDAO;
import com.example.exceptions.IdNotFoundException;
import com.example.model.MedicalRecord;
import com.example.model.Patient;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Path("/medicalrecord")
public class MedicalRecordResource {

    private static final MedicalRecordDAO medicalRecordDAO = new MedicalRecordDAO();
    private static final Logger LOGGER = LoggerFactory.getLogger(MedicalRecordResource.class);

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllMedicalRecords() {
        LOGGER.info("Fetching all medical records.");
        List<MedicalRecord> medicalRecords = medicalRecordDAO.getAllMedicalRecords();
        ObjectMapper mapper = new ObjectMapper();
        ArrayNode jsonArray = mapper.createArrayNode();

        for (MedicalRecord record : medicalRecords) {
            Patient patient = PatientResource.patientDAO.getPatientById(record.getPatientID());
            if (patient != null) {
                ObjectNode json = mapper.createObjectNode();
                json.put("id", record.getId());

                ObjectNode patientNode = mapper.createObjectNode();
                patientNode.put("id", patient.getId());
                patientNode.put("name", patient.getName());
                patientNode.put("contactNum", patient.getContactNum());
                patientNode.put("healthStatus", patient.getHealthStatus());
                json.set("patient", patientNode);

                json.put("diagnoses", record.getDiagnoses());
                json.put("treatment", record.getTreatment());

                jsonArray.add(json);
            }
        }

        try {
            String jsonResponse = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(jsonArray);
            LOGGER.info("All medical records fetched.");
            return Response.ok(jsonResponse).build();
        } catch (JsonProcessingException e) {
            LOGGER.error("Error occurred while processing JSON response.", e);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
        }
    }

    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getMedicalRecordById(@PathParam("id") String id) {
        LOGGER.info("Fetching medical record with ID: {}", id);
        MedicalRecord medicalRecord = medicalRecordDAO.getMedicalRecordById(id);
        if (medicalRecord != null) {
            Patient patient = PatientResource.patientDAO.getPatientById(medicalRecord.getPatientID());
            if (patient == null) {
                throw new IdNotFoundException("Patient", id);
            }

            ObjectMapper mapper = new ObjectMapper();
            ObjectNode json = mapper.createObjectNode();

            json.put("id", medicalRecord.getId());

            ObjectNode patientNode = mapper.createObjectNode();
            patientNode.put("id", patient.getId());
            patientNode.put("name", patient.getName());
            patientNode.put("contactNum", patient.getContactNum());
            patientNode.put("healthStatus", patient.getHealthStatus());
            json.set("patient", patientNode);

            json.put("diagnoses", medicalRecord.getDiagnoses());
            json.put("treatment", medicalRecord.getTreatment());

            try {
                String jsonResponse = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(json);
                LOGGER.info("Medical record with ID {} fetched.", id);
                return Response.ok(jsonResponse).build();
            } catch (JsonProcessingException e) {
                LOGGER.error("Error occurred while processing JSON response.", e);
                return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
            }
        } else {
            LOGGER.error("Medical record not found");
            return Response.status(Response.Status.NOT_FOUND).entity("Medical record not found").build();
        }
    }

    @GET
    @Path("/patient/{patientId}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllMedicalRecordsForPatient(@PathParam("patientId") String patientId) {
        try {
            LOGGER.info("Fetching all medical records for patient with ID: {}", patientId);
            Patient patient = PatientResource.patientDAO.getPatientById(patientId);
            if (patient == null) {
                throw new IdNotFoundException("Patient", patientId);
            }

            List<MedicalRecord> medicalRecords = medicalRecordDAO.getAllMedicalRecords();
            ObjectMapper mapper = new ObjectMapper();
            ArrayNode jsonArray = mapper.createArrayNode();

            for (MedicalRecord record : medicalRecords) {
                if (record.getPatientID().equals(patientId)) {
                    ObjectNode json = mapper.createObjectNode();

                    json.put("id", record.getId());

                    ObjectNode patientNode = mapper.createObjectNode();
                    patientNode.put("id", patient.getId());
                    patientNode.put("name", patient.getName());
                    patientNode.put("contactNum", patient.getContactNum());
                    patientNode.put("healthStatus", patient.getHealthStatus());

                    json.set("patient", patientNode);

                    json.put("diagnoses", record.getDiagnoses());
                    json.put("treatment", record.getTreatment());

                    jsonArray.add(json);
                }
            }

            String jsonResponse = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(jsonArray);
            LOGGER.info("All medical records for patient with ID {} fetched.", patientId);
            return Response.ok(jsonResponse).build();
        } catch (JsonProcessingException e) {
            LOGGER.error("Error occurred while processing JSON response.", e);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
        }
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response addMedicalRecord(MedicalRecord medicalRecord) {
        LOGGER.info("Adding new medical record.");
        medicalRecordDAO.addMedicalRecord(medicalRecord);
        return Response.status(Response.Status.CREATED).entity("Medical record created successfully").build();
    }

    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response updateMedicalRecord(@PathParam("id") String id, MedicalRecord updatedRecord) {
        try {
            LOGGER.info("Updating medical record with ID: {}", id);
            MedicalRecord existingRecord = medicalRecordDAO.getMedicalRecordById(id);
            if (existingRecord != null) {
                updatedRecord.setId(existingRecord.getId());
                medicalRecordDAO.updateMedicalRecord(updatedRecord);
                LOGGER.info("Medical record with ID {} updated.", id);
                return Response.ok().entity("Medical record updated").build();
            } else {
                throw new IdNotFoundException("Medical Record", id);
            }
        } catch (IdNotFoundException e) {
            return Response.status(Response.Status.NOT_FOUND).entity(e.getMessage()).build();
        } catch (Exception e) {
            LOGGER.error("Error occurred while updating medical record");
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Error occurred while updating medical record").build();
        }
    }

    @DELETE
    @Path("/{id}")
    public Response deleteMedicalRecordById(@PathParam("id") String id) {
        try {
            LOGGER.info("Deleting medical record with ID: {}", id);
            boolean removed = medicalRecordDAO.deleteMedicalRecordById(id);
            if (removed) {
                LOGGER.info("Medical record with ID {} deleted", id);
                return Response.status(Response.Status.NO_CONTENT).entity("Medical record deleted").build();
            } else {
                throw new IdNotFoundException("Medical Record", id);
            }
        } catch (IdNotFoundException e) {
            return Response.status(Response.Status.NOT_FOUND).entity(e.getMessage()).build();
        } catch (Exception e) {
            LOGGER.error("Error occurred while deleting medical record");
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Error occurred while deleting medical record").build();
        }
    }

}
