/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.resource;

/**
 *
 * @author Dell
 */
import com.example.dao.BillingDAO;
import com.example.exceptions.IdNotFoundException;
import com.example.model.Billing;
import com.example.model.Patient;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Path("/billing")
public class BillingResource {

    private static final Logger LOGGER = LoggerFactory.getLogger(BillingResource.class);
    private static BillingDAO billingDAO = new BillingDAO();

    // Endpoint to get all billing records
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllBillings() {
        LOGGER.info("Fetching all billing records.");
        List<Billing> billings = billingDAO.getAllBillings();

        ObjectMapper mapper = new ObjectMapper();
        ArrayNode jsonArray = mapper.createArrayNode();

        for (Billing billing : billings) {
            ObjectNode billingNode = mapper.createObjectNode();
            billingNode.put("id", billing.getId());

            Patient patient = PatientResource.patientDAO.getPatientById(billing.getPatientID());
            if (patient != null) {
                ObjectNode patientNode = mapper.createObjectNode();
                patientNode.put("id", patient.getId());
                patientNode.put("name", patient.getName());
                patientNode.put("contactNum", patient.getContactNum());
                billingNode.set("patient", patientNode);
            }

            billingNode.put("amount", billing.getAmount());
            billingNode.put("payedAmount", billing.getPayedAmount());
            jsonArray.add(billingNode);
        }

        try {
            String jsonResponse = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(jsonArray);
            return Response.ok(jsonResponse).build();
        } catch (Exception e) {
            LOGGER.error("Error occurred while fetching billing records.", e);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
        }
    }

    // Endpoint to get a specific billing record by ID
    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getBillingById(@PathParam("id") String id) {
        try {
            LOGGER.info("Fetching billing record with ID: {}", id);
            Billing billing = billingDAO.getBillingById(id);
            if (billing == null) {
                throw new IdNotFoundException("Billing", id);
            }

            Patient patient = PatientResource.patientDAO.getPatientById(billing.getPatientID());

            ObjectMapper mapper = new ObjectMapper();
            ObjectNode json = mapper.createObjectNode();

            json.put("id", billing.getId());

            ObjectNode patientNode = mapper.createObjectNode();
            patientNode.put("id", patient.getId());
            patientNode.put("name", patient.getName());
            patientNode.put("contactNum", patient.getContactNum());
            json.set("patient", patientNode);

            json.put("amount", billing.getAmount());
            json.put("payedAmount", billing.getPayedAmount());

            String jsonResponse = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(json);
            return Response.ok(jsonResponse).build();
        } catch (Exception e) {
            LOGGER.error("Error occurred while fetching billing record with ID: {}", id, e);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
        }
    }

    // Endpoint to create a new billing record
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response addBilling(Billing billing) {
        try {
            LOGGER.info("Creating new billing record.");
            // Check if the patient exists
            Patient patient = PatientResource.patientDAO.getPatientById(billing.getPatientID());
            if (patient == null) {
                throw new IdNotFoundException("Patient", billing.getPatientID());
            }

            // Patient exists, add the billing record
            billingDAO.addBilling(billing);
            LOGGER.info("Billing record created successfully.");
            return Response.status(Response.Status.CREATED)
                    .entity("Billing record created successfully")
                    .build();
        } catch (Exception e) {
            LOGGER.error("Error occurred while adding billing record");
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Error occurred while adding billing record").build();
        }
    }

    // Endpoint to update an existing billing record
    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response updateBilling(@PathParam("id") String id, Billing updatedBilling) {
        try {
            LOGGER.info("Updating billing record with ID: {}", id);
            Billing existingBilling = billingDAO.getBillingById(id);
            if (existingBilling != null) {
                updatedBilling.setId(existingBilling.getId()); // Make sure ID is set correctly
                billingDAO.updateBilling(updatedBilling);
                LOGGER.info("Billing record updated.");
                return Response.ok().entity("Billing record updated").build();
            } else {
                throw new IdNotFoundException("Billing", id);
            }
        } catch (Exception e) {
            LOGGER.error("Error occurred while updating billing record");
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Error occurred while updating billing record").build();
        }
    }

    // Endpoint to delete a billing record by ID
    @DELETE
    @Path("/{id}")
    public Response deleteBillingById(@PathParam("id") String id) {
        try {
            LOGGER.info("Deleting billing record with ID: {}", id);
            boolean deleted = billingDAO.deleteBillingById(id);
            if (deleted) {
                LOGGER.info("Billing record deleted.");
                return Response.ok().entity("Billing record deleted").build();
            } else {
                throw new IdNotFoundException("Billing", id);
            }
        } catch (Exception e) {
            LOGGER.error("Error occurred while deleting billing record", id, e);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Error occurred while deleting billing record").build();
        }
    }

    @GET
    @Path("/patient/{patientId}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllBillsForPatient(@PathParam("patientId") String patientId) {
        try {
            LOGGER.info("Fetching all billing records for patient with ID: {}", patientId);
            Patient patient = PatientResource.patientDAO.getPatientById(patientId);
            if (patient == null) {
                throw new IdNotFoundException("Patient", patientId);
            }

            List<Billing> bills = billingDAO.getAllBillingsForPatient(patientId);
            if (bills.isEmpty()) {
                LOGGER.info("No billing records found for patient with ID: {}", patientId);
                return Response.status(Response.Status.NO_CONTENT).build();
            }

            ObjectMapper mapper = new ObjectMapper();
            ArrayNode jsonArray = mapper.createArrayNode();

            for (Billing billing : bills) {
                ObjectNode billingNode = mapper.createObjectNode();
                billingNode.put("id", billing.getId());

                Patient pat = PatientResource.patientDAO.getPatientById(billing.getPatientID());
                if (pat != null) {
                    ObjectNode patientNode = mapper.createObjectNode();
                    patientNode.put("id", pat.getId());
                    patientNode.put("name", pat.getName());
                    patientNode.put("contactNum", pat.getContactNum());
                    billingNode.set("patient", patientNode);
                }

                billingNode.put("amount", billing.getAmount());
                billingNode.put("payedAmount", billing.getPayedAmount());
                jsonArray.add(billingNode);
            }

            String jsonResponse = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(jsonArray);
            return Response.ok(jsonResponse).build();
        } catch (Exception e) {
            LOGGER.error("Error occurred while fetching billing records for patient", patientId, e);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Error occurred while fetching billing records for patient").build();
        }
    }

    @GET
    @Path("/patient/balance/{patientId}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response calculateOutstandingBalance(@PathParam("patientId") String patientId) {
        try {
            LOGGER.info("Calculating outstanding balance...", patientId);
            Patient patient = PatientResource.patientDAO.getPatientById(patientId);
            if (patient == null) {
                throw new IdNotFoundException("Patient", patientId);
            }

            List<Billing> billings = billingDAO.getAllBillings();
            double totalAmount = 0;
            double totalPayedAmount = 0;

            for (Billing billing : billings) {
                if (billing.getPatientID().equals(patientId)) {
                    totalAmount += billing.getAmount();
                    totalPayedAmount += billing.getPayedAmount();
                }
            }

            double outstandingBalance = totalAmount - totalPayedAmount;
            LOGGER.info("Outstanding balance : {}", outstandingBalance);
            return Response.ok(outstandingBalance).build();
        } catch (Exception e) {
            LOGGER.error("Error occurred while calculating outstanding balance");
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Error occurred while calculating outstanding balance").build();
        }
    }
}
