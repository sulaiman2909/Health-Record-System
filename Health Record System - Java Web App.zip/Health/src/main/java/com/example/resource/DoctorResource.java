/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.resource;

/**
 *
 * @author Dell
 */
import com.example.dao.DoctorDAO;
import com.example.exceptions.IdNotFoundException;
import com.example.model.Doctor;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Path("/doctor")
public class DoctorResource {

    private static final Logger LOGGER = LoggerFactory.getLogger(DoctorResource.class);
    public static DoctorDAO doctorDAO = new DoctorDAO();

    // Endpoint to get all doctors
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllDoctors() {
        LOGGER.info("Fetching all doctors.");
        List<Doctor> doctors = doctorDAO.getAllDoctors();
        if (doctors.isEmpty()) {
            LOGGER.info("No doctors found.");
            return Response.status(Response.Status.NO_CONTENT).build();
        }
        LOGGER.info("Returning {} doctors.", doctors.size());
        return Response.ok(doctors).build();
    }

    // Endpoint to get a specific doctor by ID
    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getDoctorById(@PathParam("id") String id) {
        try {
            LOGGER.info("Fetching doctor with ID: {}", id);
            Doctor doctor = doctorDAO.getDoctorById(id);
            if (doctor == null) {
                throw new IdNotFoundException("Doctor", id);
            }
            return Response.ok(doctor).build();
        } catch (IdNotFoundException e) {
            LOGGER.error("Doctor not found with ID: {}", id);
            return Response.status(Response.Status.NOT_FOUND)
                    .entity("Doctor not found with ID: " + id)
                    .build();
        } catch (Exception e) {
            LOGGER.error("Error occurred while fetching doctor");
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Error occurred while fetching doctor").build();
        }
    }

    // Endpoint to create a new doctor
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response addDoctor(Doctor doctor) {
        try {
            doctorDAO.addDoctor(doctor);
            LOGGER.info("Doctor created.");
            return Response.status(Response.Status.CREATED).entity("Doctor Created").build();
        }
        catch(Exception e){
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Error occurred while getting doctor").build();
        }

    }

    // Endpoint to update an existing doctor
    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response updateDoctor(@PathParam("id") String id, Doctor updatedDoctor) {
        try {
            LOGGER.info("Updating doctor with ID: {}", id);
            // Check if the doctor exists
            Doctor existingDoctor = doctorDAO.getDoctorById(id);
            if (existingDoctor == null) {
                throw new IdNotFoundException("Doctor", id);
            }

            updatedDoctor.setId(id);
            doctorDAO.updateDoctor(updatedDoctor);
            LOGGER.info("Doctor updated.");
            return Response.status(Response.Status.OK).entity("Doctor updated").build();
        }catch (Exception e) {
            LOGGER.error("Error occurred while updating doctor");
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Error occurred while updating doctor").build();
        }
    }

// Endpoint to delete a doctor by ID
    @DELETE
    @Path("/{id}")
    public Response deleteDoctorById(@PathParam("id") String id) {
        try {
            LOGGER.info("Deleting doctor with ID: {}", id);
            boolean deleted = doctorDAO.deleteDoctorById(id);
            if (deleted) {
                LOGGER.info("Doctor record deleted.");
                return Response.status(Response.Status.NO_CONTENT).entity("Doctor record deleted").build();
            }
            throw new IdNotFoundException("Doctor", id);
        }catch (Exception e) {
            LOGGER.error("Error occurred while deleting doctor");
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Error occurred while deleting doctor").build();
        }
    }

}
