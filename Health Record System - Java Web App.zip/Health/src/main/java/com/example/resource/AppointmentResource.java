package com.example.resource;

import com.example.dao.AppointmentDAO;
import com.example.exceptions.IdNotFoundException;
import com.example.model.Appointment;
import com.example.model.Doctor;
import com.example.model.Patient;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Path("/appointment")
public class AppointmentResource {

    private static final AppointmentDAO appointmentDAO = new AppointmentDAO();
    private static final ObjectMapper mapper = new ObjectMapper();
    private static final Logger LOGGER = LoggerFactory.getLogger(AppointmentResource.class);

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllAppointments() {
        List<Appointment> appointments = appointmentDAO.getAllAppointments();
        if (appointments.isEmpty()) {
            LOGGER.info("No appointments found.");
            return Response.status(Response.Status.NO_CONTENT).build();
        }

        String jsonResponse = generateAppointmentsJSON(appointments);
        return Response.ok(jsonResponse).build();
    }

    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAppointmentById(@PathParam("id") String id) {
        try {
            LOGGER.info("Fetching appointment with ID: {}", id);
            Appointment appointment = appointmentDAO.getAppointmentById(id);

            if (appointment == null) {
                throw new IdNotFoundException("Appointment", id);
            }

            String jsonResponse = generateSingleAppointmentJSON(appointment);
            return Response.ok(jsonResponse).build();
        }
        catch(Exception e){
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("An error occurred while fetching data.").build(); 
        }
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response addAppointment(Appointment appointment) {
        try {
            if (DoctorResource.doctorDAO.getDoctorById(appointment.getDoctor()) == null) {
                throw new IdNotFoundException("Doctor", appointment.getDoctor());
            }

            if (PatientResource.patientDAO.getPatientById(appointment.getPatient()) == null) {
                throw new IdNotFoundException("Patient", appointment.getPatient());
            }

            List<Appointment> doctorAppointments = appointmentDAO.getDoctorsWithAppointments(appointment.getDoctor());
            for (Appointment docAppointment : doctorAppointments) {
                if (docAppointment.getDate().equals(appointment.getDate()) && docAppointment.getTime().equals(appointment.getTime())) {
                    LOGGER.error("Doctor already has an appointment at the specified time.");
                    return Response.status(Response.Status.CONFLICT)
                            .entity("Doctor already has an appointment at the specified time.")
                            .build();
                }
            }

            appointmentDAO.addAppointment(appointment);
            LOGGER.info("Appointment added.");
            return Response.status(Response.Status.CREATED).entity("Appointment added").build();
        } catch (Exception e) {
            LOGGER.error("An error occurred while processing the request.", e);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("An error occurred while processing the request.").build();
        }
    }

    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response updateAppointment(@PathParam("id") String id, Appointment updatedAppointment) {
        LOGGER.info("Updating appointment with ID: {}", id);
        Appointment existingAppointment = appointmentDAO.getAppointmentById(id);
        if (existingAppointment == null) {
            throw new IdNotFoundException("Appointment", id);
        }

        updatedAppointment.setId(id);
        appointmentDAO.updateAppointment(updatedAppointment);

        return Response.status(Response.Status.OK).entity("Appointment Updated.").build();
    }

    @DELETE
    @Path("/{id}")
    public Response deleteAppointmentById(@PathParam("id") String id) {
        try {
            LOGGER.info("Deleting appointment with ID: {}", id);
            boolean deleted = appointmentDAO.deleteAppointmentById(id);
            if (deleted) {
                LOGGER.info("Appointment with ID {} deleted.", id);
                return Response.status(Response.Status.NO_CONTENT).entity("Appointment record deleted.").build();
            }
            throw new IdNotFoundException("Appointment", id);
        } catch (Exception e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Error occured while deleting.").build();
        }
    }

    @GET
    @Path("/patient/{patientId}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAppointmentsForPatient(@PathParam("patientId") String patientId) {
        LOGGER.info("Fetching appointments for patient with ID: {}", patientId);
        List<Appointment> appointments = appointmentDAO.getPatientsWithAppointments(patientId);
        if (appointments.isEmpty()) {
            throw new IdNotFoundException("Patient", patientId);
        }

        String jsonResponse = generateAppointmentsJSON(appointments);
        return Response.ok(jsonResponse).build();
    }

    @GET
    @Path("/doctor/{doctorId}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAppointmentsForDoctor(@PathParam("doctorId") String doctorId) {
        LOGGER.info("Fetching appointments for doctor with ID: {}", doctorId);
        List<Appointment> appointments = appointmentDAO.getDoctorsWithAppointments(doctorId);
        if (appointments.isEmpty()) {
            throw new IdNotFoundException("Doctor", doctorId);
        }

        String jsonResponse = generateAppointmentsJSON(appointments);
        return Response.ok(jsonResponse).build();
    }

    private String generateAppointmentsJSON(List<Appointment> appointments) {
        ArrayNode jsonArray = mapper.createArrayNode();

        for (Appointment appointment : appointments) {
            ObjectNode json = mapper.createObjectNode();
            json.put("id", appointment.getId());
            json.put("date", appointment.getDate());
            json.put("time", appointment.getTime());

            Doctor doctor = DoctorResource.doctorDAO.getDoctorById(appointment.getDoctor());
            if (doctor != null) {
                ObjectNode doctorNode = mapper.createObjectNode();
                doctorNode.put("id", doctor.getId());
                doctorNode.put("name", doctor.getName());
                doctorNode.put("contactNum", doctor.getContactNum());
                doctorNode.put("specialization", doctor.getSpecialization());
                json.set("doctor", doctorNode);
            }

            Patient patient = PatientResource.patientDAO.getPatientById(appointment.getPatient());
            if (patient != null) {
                ObjectNode patientNode = mapper.createObjectNode();
                patientNode.put("id", patient.getId());
                patientNode.put("name", patient.getName());
                patientNode.put("contactNum", patient.getContactNum());
                patientNode.put("healthStatus", patient.getHealthStatus());
                json.set("patient", patientNode);
            }

            jsonArray.add(json);
        }

        try {
            return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(jsonArray);
        } catch (JsonProcessingException e) {
            LOGGER.error("Error generating JSON for appointments.", e);
            return "{}";
        }
    }

    private String generateSingleAppointmentJSON(Appointment appointment) {
        ObjectNode json = mapper.createObjectNode();
        json.put("id", appointment.getId());
        json.put("date", appointment.getDate());
        json.put("time", appointment.getTime());

        Doctor doctor = DoctorResource.doctorDAO.getDoctorById(appointment.getDoctor());
        if (doctor != null) {
            ObjectNode doctorNode = mapper.createObjectNode();
            doctorNode.put("id", doctor.getId());
            doctorNode.put("name", doctor.getName());
            doctorNode.put("contactNum", doctor.getContactNum());
            doctorNode.put("specialization", doctor.getSpecialization());
            json.set("doctor", doctorNode);
        }

        Patient patient = PatientResource.patientDAO.getPatientById(appointment.getPatient());
        if (patient != null) {
            ObjectNode patientNode = mapper.createObjectNode();
            patientNode.put("id", patient.getId());
            patientNode.put("name", patient.getName());
            patientNode.put("contactNum", patient.getContactNum());
            patientNode.put("healthStatus", patient.getHealthStatus());
            json.set("patient", patientNode);
        }

        try {
            return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(json);
        } catch (JsonProcessingException e) {
            LOGGER.error("Error generating JSON for single appointment.", e);
            return "{}";
        }
    }
}
