/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.resource;

/**
 *
 * @author Dell
 */
import com.example.dao.PrescriptionDAO;
import com.example.exceptions.IdNotFoundException;
import com.example.model.Doctor;
import com.example.model.Patient;
import javax.ws.rs.*;
import com.example.model.Prescription;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Path("/prescription")
public class PrescriptionResource {

    private static final PrescriptionDAO prescriptionDAO = new PrescriptionDAO();
    private static final Logger LOGGER = LoggerFactory.getLogger(PrescriptionResource.class);

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllPrescriptions() {
        List<Prescription> prescriptions = prescriptionDAO.getAllPrescriptions();
        if (prescriptions.isEmpty()) {
            LOGGER.info("No prescriptions found.");
            return Response.status(Response.Status.NO_CONTENT).build();
        }

        String jsonResponse = prescriptionsListToJson(prescriptions);
        if (jsonResponse != null) {
            LOGGER.info("All prescriptions fetched.");
            return Response.ok(jsonResponse).build();
        } else {
            LOGGER.error("Error occurred while processing prescriptions.");
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
        }
    }

    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getPrescriptionById(@PathParam("id") String id) {
        try {
            Prescription prescription = prescriptionDAO.getPrescriptionById(id);
            if (prescription == null) {
                throw new IdNotFoundException("Prescription", id);
            }

            ObjectMapper mapper = new ObjectMapper();
            ObjectNode json = mapper.createObjectNode();

            json.put("id", prescription.getId());
            json.put("dosage", prescription.getDosage());
            json.put("duration", prescription.getDuration());
            json.put("instructions", prescription.getInstructions());

            Doctor doctor = DoctorResource.doctorDAO.getDoctorById(prescription.getDoctor());
            Patient patient = PatientResource.patientDAO.getPatientById(prescription.getPatient());

            if (doctor == null || patient == null) {
                LOGGER.error("Doctor or patient not found for prescription with ID: {}", id);
                return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
            }

            ObjectNode patientNode = mapper.createObjectNode();
            patientNode.put("id", patient.getId());
            patientNode.put("name", patient.getName());
            patientNode.put("contactNum", patient.getContactNum());
            patientNode.put("healthStatus", patient.getHealthStatus());

            ObjectNode doctorNode = mapper.createObjectNode();
            doctorNode.put("id", doctor.getId());
            doctorNode.put("name", doctor.getName());
            doctorNode.put("contactNum", doctor.getContactNum());
            doctorNode.put("specialization", doctor.getSpecialization());

            json.set("patient", patientNode);
            json.set("doctor", doctorNode);

            String jsonResponse = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(json);
            LOGGER.info("Prescription with ID {} fetched successfully.", id);
            return Response.ok(jsonResponse).build();
        } catch (Exception e) {
            LOGGER.error("Error occurred while processing JSON response.", e);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Error occurred while processing JSON response.").build();
        }

    }

    @GET
    @Path("/patient/{patientId}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllPrescriptionsForPatient(@PathParam("patientId") String patientId) {
        try {
            List<Prescription> prescriptions = prescriptionDAO.getPrescriptionsForPatient(patientId);
            if (prescriptions.isEmpty()) {
                LOGGER.info("No prescriptions found for patient with ID: {}", patientId);
                return Response.status(Response.Status.NO_CONTENT).build();
            }

            String jsonResponse = prescriptionsListToJson(prescriptions);
            if (jsonResponse != null) {
                LOGGER.info("Prescriptions for patient with ID {} fetched.", patientId);
                return Response.ok(jsonResponse).build();
            } else {
                LOGGER.error("Error occurred while processing prescriptions.");
                return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
            }
        } catch (Exception e) {
            LOGGER.error("Error occurred while fetching prescriptions for patient with ID: {}", patientId, e);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Error occurred while fetching prescriptions.").build();
        }
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response addPrescription(Prescription prescription) {
        LOGGER.info("Adding new prescription.");
        try {
            Doctor doctor = DoctorResource.doctorDAO.getDoctorById(prescription.getDoctor());
            if (doctor == null) {
                throw new IdNotFoundException("Doctor", prescription.getDoctor());
            }

            Patient patient = PatientResource.patientDAO.getPatientById(prescription.getPatient());
            if (patient == null) {
                throw new IdNotFoundException("Patient", prescription.getPatient());
            }

            prescriptionDAO.addPrescription(prescription);
            LOGGER.info("Prescription added.");
            return Response.status(Response.Status.CREATED).entity("Prescription added").build();
        } catch (Exception e) {
            LOGGER.error("Error occurred while adding prescription.", e);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("An error occurred").build();
        }
    }

    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response updatePrescription(@PathParam("id") String id, Prescription updatedPrescription) {
        try {
            Prescription existingPrescription = prescriptionDAO.getPrescriptionById(id);
            if (existingPrescription == null) {
                throw new IdNotFoundException("Prescription", id);
            }

            updatedPrescription.setId(id);
            prescriptionDAO.updatePrescription(updatedPrescription);

            return Response.status(Response.Status.OK).entity("Prescription Updated").build();
        } catch (Exception e) {
            LOGGER.error("Error occurred while updating prescription record");
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Error occurred while updating prescription record").build();
        }
    }

    @DELETE
    @Path("/{id}")
    public Response deletePrescriptionById(@PathParam("id") String id) {
        try {
            boolean deleted = prescriptionDAO.deletePrescriptionById(id);
            if (deleted) {
                LOGGER.info("Prescription with ID {} deleted.", id);
                return Response.status(Response.Status.NO_CONTENT).entity("Prescription record deleted").build();
            } else {
                throw new IdNotFoundException("Prescription", id);
            }
        } catch (IdNotFoundException e) {
            return Response.status(Response.Status.NOT_FOUND).entity(e.getMessage()).build();
        } catch (Exception e) {
            LOGGER.error("Error occurred while deleting prescription record");
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Error occurred while deleting prescription record").build();
        }
    }

    private String prescriptionsListToJson(List<Prescription> prescriptions) {
        ObjectMapper mapper = new ObjectMapper();
        ArrayNode jsonArray = mapper.createArrayNode();

        for (Prescription prescription : prescriptions) {
            Doctor doctor = DoctorResource.doctorDAO.getDoctorById(prescription.getDoctor());
            Patient patient = PatientResource.patientDAO.getPatientById(prescription.getPatient());

            ObjectNode json = mapper.createObjectNode();

            json.put("id", prescription.getId());
            json.put("dosage", prescription.getDosage());
            json.put("duration", prescription.getDuration());
            json.put("instructions", prescription.getInstructions());

            ObjectNode patientNode = mapper.createObjectNode();
            patientNode.put("id", patient.getId());
            patientNode.put("name", patient.getName());
            patientNode.put("contactNum", patient.getContactNum());
            patientNode.put("healthStatus", patient.getHealthStatus());

            ObjectNode doctorNode = mapper.createObjectNode();
            doctorNode.put("id", doctor.getId());
            doctorNode.put("name", doctor.getName());
            doctorNode.put("contactNum", doctor.getContactNum());
            doctorNode.put("specialization", doctor.getSpecialization());

            json.set("patient", patientNode);
            json.set("doctor", doctorNode);

            jsonArray.add(json);
        }

        try {
            return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(jsonArray);
        } catch (Exception e) {
            LOGGER.error("Error occurred while processing prescriptions.", e);
            return null;
        }
    }
}
