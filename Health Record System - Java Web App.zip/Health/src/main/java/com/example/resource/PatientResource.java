/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.resource;

/**
 *
 * @author Dell
 */
import com.example.dao.PatientDAO;
import com.example.exceptions.IdNotFoundException;
import com.example.model.Patient;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Path("/patient")
public class PatientResource {

    public static PatientDAO patientDAO = new PatientDAO();

    private static final Logger LOGGER = LoggerFactory.getLogger(PatientResource.class);

    // Endpoint to get all patients
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllPatients() {
        try {
            List<Patient> patients = patientDAO.getAllPatients();
            if (patients.isEmpty()) {
                LOGGER.info("No patients found.");
                return Response.status(Response.Status.NO_CONTENT).build();
            }
            LOGGER.info("Retrieved all patients.");
            return Response.ok(patients).build();
        } catch (Exception e) {
            LOGGER.error("Error occurred while getting all patients", e);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Error occurred").build();
        }
    }

    // Endpoint to get a specific patient by ID
    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getPatientById(@PathParam("id") String id) {
        try {
            Patient patient = patientDAO.getPatientById(id);
            if (patient == null) {
                throw new IdNotFoundException("Patient",id);
            }
            LOGGER.info("Retrieved patient with ID: {}", id);
            return Response.ok(patient).build();
        } catch (Exception e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Error occurred while getting patient").build();
        }
    }

    // Endpoint to create a new patient
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response addPatient(Patient patient) {
        try {
            patientDAO.addPatient(patient);
            LOGGER.info("New patient added with ID: {}", patient.getId());
            return Response.status(Response.Status.CREATED).entity("Patient Created").build();
        } catch (Exception e) {
            LOGGER.error("Error occurred while adding a new patient", e);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Error occurred while adding a new patient").build();
        }
    }

    // Endpoint to update an existing patient
    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response updatePatient(@PathParam("id") String id, Patient updatedPatient) {
        try {
            // Check if the patient exists
            Patient existingPatient = patientDAO.getPatientById(id);
            if (existingPatient == null) {
                throw new IdNotFoundException("Patient",id);
            }

            updatedPatient.setId(id);
            patientDAO.updatePatient(updatedPatient);

            LOGGER.info("Patient with ID {} updated.", id);
            return Response.status(Response.Status.OK).entity("Patient Updated").build();
        } catch (Exception e) {
            LOGGER.error("Error occurred while updating patient with ID: {}", id, e);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Error occurred").build();
        }
    }

    // Endpoint to delete a patient by ID
    @DELETE
    @Path("/{id}")
    public Response deletePatientById(@PathParam("id") String id) {
        try {
            boolean deleted = patientDAO.deletePatientById(id);
            if (deleted) {
                LOGGER.info("Patient with ID {} deleted.", id);
                return Response.status(Response.Status.NO_CONTENT).entity("Patient record deleted").build();
            }
            throw new IdNotFoundException("Patient",id);
        } catch (Exception e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Error occurred while deleting patient").build();
        }
    }
}