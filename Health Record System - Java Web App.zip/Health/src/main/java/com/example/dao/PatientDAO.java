/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.dao;

/**
 *
 * @author Dell
 */
import com.example.model.Patient;
import java.util.ArrayList;
import java.util.List;

public class PatientDAO {

    private List<Patient> patients;
    private int idCounter;

    public PatientDAO() {
        // Initialize an empty list of patients
        this.patients = new ArrayList<>();
        // Initialize ID counter
        this.idCounter = 1; // Start from 1
        
        patients.add(new Patient(generateId(), "John Doe", "123 Main St", "1234567890", "Stable"));
        patients.add(new Patient(generateId(), "Alice Smith", "456 Oak Ave", "9876543210", "Stable"));
        patients.add(new Patient(generateId(), "Bob Johnson", "789 Elm St", "4561237890", "Stable"));
    }

    // Create operation: Add a new patient
    public void addPatient(Patient patient) {
        // Generate unique ID and assign it to the patient
        patient.setId(generateId());
        patients.add(patient);
    }

    // Read operation: Retrieve a patient by ID
    public Patient getPatientById(String id) {
        for (Patient patient : patients) {
            if (patient.getId().equals(id)) {
                return patient;
            }
        }
        return null; // Patient with given ID not found
    }

    // Update operation: Update details of an existing patient
    public void updatePatient(Patient updatedPatient) {
        for (Patient patient : patients) {
            if (patient.getId().equals(updatedPatient.getId())) {
                // Update inherited Person properties
                patient.setName(updatedPatient.getName());
                patient.setContactNum(updatedPatient.getContactNum());
                patient.setAddress(updatedPatient.getAddress());
                // Update specific Patient properties
                patient.setHealthStatus(updatedPatient.getHealthStatus());
                return; // Exit loop after updating
            }
        }
        // If patient with given ID not found, do nothing
    }

    // Delete operation: Remove a patient by ID
    public boolean deletePatientById(String id) {
        // Remove the patient if found by ID
        boolean removed = patients.removeIf(patient -> patient.getId().equals(id));
        return removed;
    }

    // Read operation: Retrieve all patients (override to return List<Patient>)
    public List<Patient> getAllPatients() {
        return patients;
    }

    // Method to generate a unique ID
    private String generateId() {
        String idPrefix = "P-";
        String uniqueId = idPrefix + idCounter;
        idCounter++; // Increment the ID counter for the next ID
        return uniqueId;
    }
}
