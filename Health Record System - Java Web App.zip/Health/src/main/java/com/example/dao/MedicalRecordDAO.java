/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.dao;

/**
 *
 * @author Dell
 */
import com.example.model.MedicalRecord;
import java.util.ArrayList;
import java.util.List;

public class MedicalRecordDAO {
    private static List<MedicalRecord> medicalRecords;
    private static int nextId = 1;

    public MedicalRecordDAO() {
        medicalRecords = new ArrayList<>();
        
        medicalRecords.add(new MedicalRecord(generateId(), "P-1", "Fever", "Rest and fluids"));
        medicalRecords.add(new MedicalRecord(generateId(), "P-2", "Headache", "Painkillers and rest"));
        medicalRecords.add(new MedicalRecord(generateId(), "P-3", "Sore throat", "Gargle with salt water"));
    
    }

    // Method to add a new medical record
    public void addMedicalRecord(MedicalRecord medicalRecord) {
        medicalRecord.setId(generateId());
        medicalRecords.add(medicalRecord);
    }

    // Method to retrieve all medical records
    public List<MedicalRecord> getAllMedicalRecords() {
        return medicalRecords;
    }

    // Method to retrieve a medical record by its ID
    public MedicalRecord getMedicalRecordById(String id) {
        for (MedicalRecord record : medicalRecords) {
            if (record.getId().equals(id)) {
                return record;
            }
        }
        return null; // Return null if medical record with specified ID is not found
    }

    // Method to update an existing medical record
    public void updateMedicalRecord(MedicalRecord updatedRecord) {
        for (MedicalRecord record : medicalRecords) {
            if (record.getId().equals(updatedRecord.getId())) {
                record.setPatientID(updatedRecord.getPatientID());
                record.setDiagnoses(updatedRecord.getDiagnoses());
                record.setTreatment(updatedRecord.getTreatment());
                return;
            }
        }
    }

    // Method to delete a medical record by its ID
    public boolean deleteMedicalRecordById(String id) {
        return medicalRecords.removeIf(record -> record.getId().equals(id));
    }

    // Helper method to generate unique IDs for medical records
    private String generateId() {
        return "MR-" + nextId++;
    }
}
