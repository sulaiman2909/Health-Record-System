/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.dao;

/**
 *
 * @author Dell
 */

import com.example.model.Doctor;
import java.util.ArrayList;
import java.util.List;

public class DoctorDAO {
    private List<Doctor> doctors;
    private int nextId = 1;

    public DoctorDAO() {
        // Initialize an empty list of doctors
        this.doctors = new ArrayList<>();
        
        doctors.add(new Doctor(generateId(), "Dr. Smith", "12345", "123 Elm St", "Cardiologist"));
        doctors.add(new Doctor(generateId(), "Dr. Johnson", "54321", "456 Oak St", "Neurologist"));
        doctors.add(new Doctor(generateId(), "Dr. Brown", "98765", "789 Main St", "Dermatologist"));
    }

    // Create operation: Add a new doctor
    public void addDoctor(Doctor doctor) {
        // Generate unique ID and assign it to the doctor
        doctor.setId(generateId());
        doctors.add(doctor);
    }

    // Read operation: Retrieve a doctor by ID
    public Doctor getDoctorById(String id) {
        for (Doctor doctor : doctors) {
            if (doctor.getId().equals(id)) {
                return doctor;
            }
        }
        return null; // Doctor with given ID not found
    }

    // Update operation: Update details of an existing doctor
    public void updateDoctor(Doctor updatedDoctor) {
        for (Doctor doctor : doctors) {
            if (doctor.getId().equals(updatedDoctor.getId())) {
                // Update inherited Person properties
                doctor.setName(updatedDoctor.getName());
                doctor.setContactNum(updatedDoctor.getContactNum());
                doctor.setAddress(updatedDoctor.getAddress());
                // Update specific Doctor properties
                doctor.setSpecialization(updatedDoctor.getSpecialization());
                return; // Exit loop after updating
            }
        }
        // If doctor with given ID not found, do nothing
    }

    // Delete operation: Remove a doctor by ID
    public boolean deleteDoctorById(String id) {
        boolean removed = doctors.removeIf(doctor -> doctor.getId().equals(id));
        return removed;
    }

    // Read operation: Retrieve all doctors
    public List<Doctor> getAllDoctors() {
        return doctors;
    }

    // Method to generate a unique ID
    private String generateId() {
        return "D-" + nextId++;
    }
}
