/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.dao;

import com.example.model.Appointment;
import java.util.ArrayList;
import java.util.List;

public class AppointmentDAO {

    private List<Appointment> appointments;
    private int nextId = 1;

    public AppointmentDAO() {
        // Initialize an empty list of appointments
        this.appointments = new ArrayList<>();
        
        appointments.add(new Appointment(generateId(), "D-1", "P-1", "2024-05-03", "10:00"));
        appointments.add(new Appointment(generateId(), "D-2", "P-2", "2024-05-04", "11:00"));
        appointments.add(new Appointment(generateId(), "D-1", "P-3", "2024-05-05", "12:00"));
        
    }

    // Create operation: Add a new appointment
    public void addAppointment(Appointment appointment) {
        appointment.setId(generateId());
        appointments.add(appointment);
    }

    // Read operation: Retrieve an appointment by ID
    public Appointment getAppointmentById(String id) {
        for (Appointment appointment : appointments) {
            if (appointment.getId().equals(id)) {
                return appointment;
            }
        }
        return null; // Appointment with given ID not found
    }
    
    public List<Appointment> getPatientsWithAppointments(String patientID) {
        List<Appointment> appointmentsForPatient = new ArrayList<>();
        
        for (Appointment appointment : appointments) {
            if (appointment.getPatient().equals(patientID)) {
                appointmentsForPatient.add(appointment);
            }
        }
        return appointmentsForPatient;
    }

    public List<Appointment> getDoctorsWithAppointments(String doctorID) {
        List<Appointment> doctorsWithAppointments = new ArrayList<>();
        for (Appointment appointment : appointments) {
            if (appointment.getDoctor().equals(doctorID)) {
                doctorsWithAppointments.add(appointment);
            }
        }
        return doctorsWithAppointments;
    }

    // Update operation: Update details of an existing appointment
    public void updateAppointment(Appointment updatedAppointment) {
        for (Appointment appointment : appointments) {
            if (appointment.getId().equals(updatedAppointment.getId())) {
                appointment.setDoctor(updatedAppointment.getDoctor());
                appointment.setPatient(updatedAppointment.getPatient());
                appointment.setDate(updatedAppointment.getDate());
                appointment.setTime(updatedAppointment.getTime());
                return; // Exit loop after updating
            }
        }
        // If appointment with given ID not found, do nothing
    }

    // Delete operation: Remove an appointment by ID
    public boolean deleteAppointmentById(String id) {
        boolean removed = appointments.removeIf(appointment -> appointment.getId().equals(id));
        return removed;
    }

    // Read operation: Retrieve all appointments
    public List<Appointment> getAllAppointments() {
        return appointments;
    }

    // Helper method to generate unique IDs for appointments
    private String generateId() {
        return "A-" + nextId++;
    }
}
