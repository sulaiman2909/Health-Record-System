/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.dao;

/**
 *
 * @author Dell
 */
import com.example.model.Prescription;
import java.util.ArrayList;
import java.util.List;

public class PrescriptionDAO {

    private List<Prescription> prescriptions;
    private int nextId = 1; // Counter for generating unique IDs

    public PrescriptionDAO() {
        // Initialize an empty list of prescriptions
        this.prescriptions = new ArrayList<>();

        prescriptions.add(new Prescription(generateId(), "D-1", "P-1", "Aspirin", "1 tablet daily", "7 days"));
        prescriptions.add(new Prescription(generateId(), "D-2", "P-2", "Paracetamol", "2 tablets as needed", "14 days"));
        prescriptions.add(new Prescription(generateId(), "D-1", "P-3", "Antibiotics", "Take with meals", "10 days"));

    }

    // Create operation: Add a new prescription
    public void addPrescription(Prescription prescription) {
        prescription.setId(generateId()); // Assign unique ID
        prescriptions.add(prescription);
    }

    // Read operation: Retrieve a prescription by ID
    public Prescription getPrescriptionById(String id) {
        for (Prescription prescription : prescriptions) {
            if (prescription.getId().equals(id)) {
                return prescription;
            }
        }
        return null; // Prescription with given ID not found
    }

    // Update operation: Update details of an existing prescription
    public void updatePrescription(Prescription updatedPrescription) {
        for (Prescription prescription : prescriptions) {
            if (prescription.getId() == updatedPrescription.getId()) {
                prescription.setDoctor(updatedPrescription.getDoctor());
                prescription.setPatient(updatedPrescription.getPatient());
                prescription.setDosage(updatedPrescription.getDosage());
                prescription.setDuration(updatedPrescription.getDuration());
                prescription.setInstructions(updatedPrescription.getInstructions());
                return; // Exit loop after updating
            }
        }
        // If prescription with given ID not found, do nothing
    }

    // Delete operation: Remove a prescription by ID
    public boolean deletePrescriptionById(String id) {
        boolean removed = prescriptions.removeIf(prescription -> prescription.getId() == id);
        return removed;
    }

    // Read operation: Retrieve all prescriptions
    public List<Prescription> getAllPrescriptions() {
        return prescriptions;
    }

    // Method to retrieve all prescriptions for a specific patient
    public List<Prescription> getPrescriptionsForPatient(String patientId) {
        List<Prescription> patientPrescriptions = new ArrayList<>();
        for (Prescription prescription : prescriptions) {
            if (prescription.getPatient().equals(patientId)) {
                patientPrescriptions.add(prescription);
            }
        }
        return patientPrescriptions;
    }

    // Generate a unique ID for prescriptions
    private String generateId() {
        return "PR-" + nextId++;
    }
}
