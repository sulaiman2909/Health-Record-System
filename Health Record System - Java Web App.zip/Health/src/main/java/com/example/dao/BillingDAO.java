/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.dao;

/**
 *
 * @author Dell
 */
import com.example.model.Billing;
import java.util.ArrayList;
import java.util.List;

public class BillingDAO {
    private static List<Billing> billings;
    private int nextId = 1;
    
    public BillingDAO(){
        this.billings = new ArrayList<>();
        
        billings.add(new Billing(generateId(), "P-1", 500.0, 0.0));
        billings.add(new Billing(generateId(), "P-2", 750.0, 200.0));
        billings.add(new Billing(generateId(), "P-3", 1000.0, 500.0));
        
    }

    // Method to add a new billing record
    public void addBilling(Billing billing) {
        billing.setId(generateId());
        billings.add(billing);
    }

    // Method to retrieve all billing records
    public List<Billing> getAllBillings() {
        return billings;
    }

    // Method to retrieve a billing record by ID
    public Billing getBillingById(String id) {
        for (Billing billing : billings) {
            if (billing.getId() == id) {
                return billing;
            }
        }
        return null; // Return null if billing record with specified ID is not found
    }
    
    // Method to retrieve all billing records for a specific patient
    public List<Billing> getAllBillingsForPatient(String patientId) {
        List<Billing> billsForPatient = new ArrayList<>();
        for (Billing billing : billings) {
            if (billing.getPatientID().equals(patientId)) {
                billsForPatient.add(billing);
            }
        }
        return billsForPatient;
    }

    // Method to update an existing billing record
    public void updateBilling(Billing updatedBilling) {
        for (Billing billing : billings) {
            if (billing.getId() == updatedBilling.getId()) {
                // Update the billing record with the new values
                billing.setPatientID(updatedBilling.getPatientID());
                billing.setAmount(updatedBilling.getAmount());
                billing.setPayedAmount(updatedBilling.getPayedAmount());
                return;
            }
        }
    }

    // Method to delete a billing record by ID
    public boolean deleteBillingById(String id) {
        boolean removed = billings.removeIf(billing -> billing.getId() == id);
        return removed;
    }

    // Generate a unique ID for billing records
    private String generateId() {
        return "B-" + nextId++;
    }
}
